// =============================================
//  script.js — Customer Feedback AI Agent
// =============================================

document.addEventListener('DOMContentLoaded', () => {

  // ── 1. HAMBURGER SIDEBAR TOGGLE ──────────────
  const hamburger = document.getElementById('hamburgerBtn');
  const sidebar   = document.getElementById('sidebar');
  const overlay   = document.getElementById('sidebarOverlay');

  if (hamburger && sidebar) {
    hamburger.addEventListener('click', () => {
      sidebar.classList.toggle('open');
      if (overlay) overlay.classList.toggle('show');
    });
  }

  if (overlay) {
    overlay.addEventListener('click', () => {
      sidebar.classList.remove('open');
      overlay.classList.remove('show');
    });
  }

  // ── 2. ACTIVE NAV LINK (berdasarkan halaman saat ini) ──
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-link').forEach(link => {
    const href = link.getAttribute('href');
    if (href && href.includes(currentPage)) {
      link.classList.add('active');
    }
  });

  // ── 3. AUTO-SAVE TEXTAREA KE LOCALSTORAGE ────
  document.querySelectorAll('textarea[data-save-key], input[data-save-key]').forEach(el => {
    const key = el.getAttribute('data-save-key');

    // Load saved value
    const saved = localStorage.getItem(key);
    if (saved !== null) {
      el.value = saved;
    }

    // Save on input
    el.addEventListener('input', () => {
      localStorage.setItem(key, el.value);
      showSaveIndicator();
    });
  });

  // ── 4. SAVE INDICATOR ────────────────────────
  function showSaveIndicator() {
    const indicator = document.getElementById('saveIndicator');
    if (!indicator) return;
    indicator.textContent = '✓ Tersimpan otomatis';
    indicator.style.opacity = '1';
    clearTimeout(indicator._timer);
    indicator._timer = setTimeout(() => {
      indicator.style.opacity = '0';
    }, 2000);
  }

  // ── 5. CLEAR / RESET FORM ────────────────────
  const resetBtn = document.getElementById('resetFormBtn');
  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      if (!confirm('Reset semua isian di halaman ini?')) return;
      document.querySelectorAll('textarea[data-save-key], input[data-save-key]').forEach(el => {
        const key = el.getAttribute('data-save-key');
        localStorage.removeItem(key);
        el.value = '';
      });
    });
  }

  // ── 6. WORD COUNT (untuk textarea dengan data-wordcount) ──
  document.querySelectorAll('textarea[data-wordcount]').forEach(ta => {
    const targetId = ta.getAttribute('data-wordcount');
    const counter  = document.getElementById(targetId);
    if (!counter) return;

    function updateCount() {
      const words = ta.value.trim() === '' ? 0 : ta.value.trim().split(/\s+/).length;
      counter.textContent = `${words} kata`;
    }

    ta.addEventListener('input', updateCount);
    updateCount(); // initial
  });

  // ── 7. PROGRESS TRACKER (halaman yang sudah diisi) ──
  updateProgressTracker();

  function updateProgressTracker() {
    const pages = [
      { key: 'ringkasan_overview',    dotId: 'dot-ringkasan'  },
      { key: 'problem_statement',     dotId: 'dot-problem'    },
      { key: 'target_users',          dotId: 'dot-users'      },
      { key: 'prompt_architecture',   dotId: 'dot-prompt'     },
    ];

    pages.forEach(({ key, dotId }) => {
      const dot = document.getElementById(dotId);
      if (!dot) return;
      const saved = localStorage.getItem(key);
      if (saved && saved.trim().length > 20) {
        dot.classList.add('done');
      }
    });
  }

  // ── 8. COPY TO CLIPBOARD ─────────────────────
  document.querySelectorAll('[data-copy-target]').forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-copy-target');
      const el = document.getElementById(targetId);
      if (!el) return;
      navigator.clipboard.writeText(el.value || el.textContent).then(() => {
        const original = btn.textContent;
        btn.textContent = '✓ Disalin!';
        setTimeout(() => { btn.textContent = original; }, 1500);
      });
    });
  });

  // ── 9. SMOOTH SCROLL untuk anchor internal ───
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', e => {
      const target = document.querySelector(anchor.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

});
